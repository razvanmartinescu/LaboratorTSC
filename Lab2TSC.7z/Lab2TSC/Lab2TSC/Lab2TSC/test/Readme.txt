Test file to see if the Verilog simulator installation for the
training class is correct.

NOTE: Different Verilog simulators have different invocation
commands.  Following is the invocation command for the

   verilog test.v

The output of the simulator should display the following results:


Hello World!


$finish called at simulation time 10